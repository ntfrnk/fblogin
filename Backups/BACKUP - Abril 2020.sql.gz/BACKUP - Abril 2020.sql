-- Adminer 4.2.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `pow_comunicaciones`;
CREATE TABLE `pow_comunicaciones` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `tipoID` int(11) NOT NULL,
  `mensaje` text COLLATE utf8_unicode_ci NOT NULL,
  `visto` int(1) NOT NULL,
  `cerrado` int(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `pow_comunicaciones_tipos`;
CREATE TABLE `pow_comunicaciones_tipos` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pow_comunicaciones_tipos` (`Id`, `tipo`, `color`) VALUES
(1,	'Urgente',	'danger'),
(2,	'Información',	'info'),
(3,	'Advertencia',	'warning'),
(4,	'Noticia',	'primary'),
(5,	'Comunicado',	'secondary'),
(6,	'Éxito',	'success');

DROP TABLE IF EXISTS `pow_cursos`;
CREATE TABLE `pow_cursos` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `profesores` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pow_cursos` (`Id`, `nombre`, `profesores`, `descripcion`, `fecha`, `active`) VALUES
(1,	'Super curso de Talita-Kumi con titulo más largo',	'',	'Curso de sanidad interior para mujeres.',	'2020-11-30',	1),
(2,	'Curso tremendo de Tantana-Kuy con un título demasiado largo',	'',	'Curso de sanidad interior para hombres.',	'2020-01-01',	1),
(3,	'Tercer curso',	'',	'Using color to add meaning only provides a visual indication, which will not be conveyed to users of assistive technologies – such as screen readers.',	'2020-01-01',	1),
(4,	'Este es un cuarto curso',	'',	'',	'2020-02-12',	1);

DROP TABLE IF EXISTS `pow_cursos_clases`;
CREATE TABLE `pow_cursos_clases` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `cursoID` int(11) NOT NULL,
  `titulo` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `video` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `placa` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `inicio` date NOT NULL,
  `final` date NOT NULL,
  `orden` int(1) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pow_cursos_clases` (`Id`, `cursoID`, `titulo`, `video`, `placa`, `inicio`, `final`, `orden`, `active`) VALUES
(1,	1,	'Clase Nº 1 - Introducción',	'https://mega.nz/embed#!7oFWyYKC!irnXwbslP9GTNk07pPVleDu7AMluxtFIQsj6rmjZUXc',	'',	'2020-01-01',	'2020-04-15',	0,	1),
(3,	1,	'Clase Nº 2 - Afrontando la situación',	'https://mega.nz/embed#!7oFWyYKC!irnXwbslP9GTNk07pPVleDu7AMluxtFIQsj6rmjZUXc',	'',	'2020-01-15',	'2020-01-31',	0,	1),
(4,	2,	'Clase #1 - Primera clase del año',	'',	'',	'2020-01-01',	'2020-01-01',	0,	1),
(5,	2,	'Clase #2 - Segunda clase del año',	'',	'',	'2020-01-01',	'2020-01-01',	0,	1),
(6,	2,	'Clase #3 - Tercera clase del año',	'',	'',	'2020-01-01',	'2020-01-01',	0,	1),
(7,	2,	'Clase #4 - Cuarta clase del año',	'',	'',	'2020-01-01',	'2020-01-01',	0,	1),
(8,	1,	'Clase Nº 3 - Esta es otra clase más',	'https://mega.nz/embed#!7oFWyYKC!irnXwbslP9GTNk07pPVleDu7AMluxtFIQsj6rmjZUXc',	'',	'2020-02-01',	'2020-02-15',	0,	1),
(9,	1,	'Clase Nº 4 - Clase de cómo dar clases',	'',	'',	'2020-02-01',	'2020-02-29',	0,	1),
(10,	1,	'Clase Nº 5 - La primera del mes de marzo',	'',	'',	'2020-03-01',	'2020-03-15',	0,	1),
(16,	1,	'Clase Nº 6 - La última clase de este cursado',	'https://mega.nz/#!7oFWyYKC!irnXwbslP9GTNk07pPVleDu7AMluxtFIQsj6rmjZUXc',	'c74d97b01eae257e44aa9d5bade97baf.jpg',	'2020-01-02',	'2021-01-02',	0,	1);

DROP TABLE IF EXISTS `pow_cursos_clases_adjuntos`;
CREATE TABLE `pow_cursos_clases_adjuntos` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `claseID` int(11) NOT NULL,
  `archivo` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pow_cursos_clases_adjuntos` (`Id`, `claseID`, `archivo`, `link`) VALUES
(47,	8,	'00218 - Fundación Familia - Sitio Web.pdf',	''),
(48,	8,	'AAAAAAAAAAAAAA.mp4',	'');

DROP TABLE IF EXISTS `pow_cursos_clases_preguntas`;
CREATE TABLE `pow_cursos_clases_preguntas` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `claseID` int(11) NOT NULL,
  `pregunta` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `orden` int(2) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pow_cursos_clases_preguntas` (`Id`, `claseID`, `pregunta`, `orden`) VALUES
(7,	8,	'Describa el proceso de abordaje',	0),
(8,	8,	'Enumere tres casos de abordaje inmediato',	1),
(9,	8,	'Menciona cinco casos prioritarios de acción',	2),
(10,	9,	'Esta es una pregunta',	0),
(11,	9,	'Otra pregunta más',	1),
(12,	9,	'Tercera pregunta',	2),
(13,	9,	'Y esta sería la última',	3),
(14,	1,	'Mira este video y responde qué te parece: https://www.youtube.com/watch?v=NsTrSNfDkKo',	0);

DROP TABLE IF EXISTS `pow_mensajes`;
CREATE TABLE `pow_mensajes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `remitenteID` int(11) NOT NULL,
  `destinatarioID` int(11) NOT NULL,
  `mensaje` text COLLATE utf8_unicode_ci NOT NULL,
  `enviado` datetime NOT NULL,
  `leido` datetime NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pow_mensajes` (`Id`, `remitenteID`, `destinatarioID`, `mensaje`, `enviado`, `leido`) VALUES
(2,	3,	3,	'Acordáte de que tenés que pagar.',	'2020-01-16 00:46:59',	'2020-02-03 23:26:47'),
(3,	3,	7,	'Buenas tardes Julieta, necesitamos por favor que te pongas en contacto con nosotros.',	'2020-02-03 23:05:17',	'2020-02-03 23:05:51'),
(4,	3,	147,	'Hola Ruth!! Necesitamos que abones lo adeudado.',	'2020-03-01 23:09:46',	'0000-00-00 00:00:00'),
(5,	3,	147,	'Ruth, te informamos que en el caso de no abonar el monto adeudado no podrás seguir cursando.',	'2020-03-01 23:14:45',	'0000-00-00 00:00:00'),
(6,	3,	147,	'Ruth, en breve vamos a dar de baja tu usuario debido a tu falta de pago.',	'2020-03-01 23:15:07',	'0000-00-00 00:00:00'),
(7,	3,	147,	'Ruth, suspendemos tu cursado hasta que puedas abonar lo pactado.',	'2020-03-01 23:15:27',	'0000-00-00 00:00:00');

DROP TABLE IF EXISTS `pow_users`;
CREATE TABLE `pow_users` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `active` int(1) NOT NULL,
  `datos` int(1) NOT NULL,
  `documentos` int(1) NOT NULL,
  `money` int(1) NOT NULL,
  `approved` int(1) NOT NULL,
  `admin` int(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pow_users` (`Id`, `user`, `pass`, `email`, `active`, `datos`, `documentos`, `money`, `approved`, `admin`) VALUES
(3,	'',	'f1e5c64fca3e3217702be0837b2b64ec',	'netfrank777@gmail.com',	1,	0,	0,	1,	0,	1),
(6,	'',	'f1e5c64fca3e3217702be0837b2b64ec',	'tommyoca@gmail.com',	1,	0,	0,	0,	0,	0),
(133,	'',	'07ac117486a82157d3c65b11c048341d',	'alexiajanet555@gmail.com',	1,	0,	0,	0,	0,	0),
(134,	'',	'07ac117486a82157d3c65b11c048341d',	'alibeza49@hotmail.com',	1,	0,	0,	0,	0,	0),
(135,	'',	'07ac117486a82157d3c65b11c048341d',	'arandamonica39@gmail.com',	1,	0,	0,	0,	0,	0),
(136,	'',	'07ac117486a82157d3c65b11c048341d',	'ayaviviana@gmail.com',	1,	0,	0,	0,	0,	0),
(137,	'',	'07ac117486a82157d3c65b11c048341d',	'belu2809@gmail.com',	1,	0,	0,	0,	0,	0),
(138,	'',	'07ac117486a82157d3c65b11c048341d',	'betianapaolasalvo37@gmail.com',	1,	0,	0,	0,	0,	0),
(139,	'',	'07ac117486a82157d3c65b11c048341d',	'carlataboada74@gmail.com',	1,	0,	0,	0,	0,	0),
(140,	'',	'07ac117486a82157d3c65b11c048341d',	'carlosmunozr@hotmail.com',	1,	0,	0,	0,	0,	0),
(141,	'',	'07ac117486a82157d3c65b11c048341d',	'catalinarazo@hotmail.com',	1,	0,	0,	0,	0,	0),
(142,	'',	'07ac117486a82157d3c65b11c048341d',	'ccaprarulo15@gmail.com',	1,	0,	0,	0,	0,	0),
(143,	'',	'07ac117486a82157d3c65b11c048341d',	'celemariojonyabi2014@gmail.com',	1,	0,	0,	0,	0,	0),
(144,	'',	'07ac117486a82157d3c65b11c048341d',	'claugarcia1407@gmail.com',	1,	0,	0,	0,	0,	0),
(145,	'',	'07ac117486a82157d3c65b11c048341d',	'cpamela_sanchezb@hotmail.com',	1,	0,	0,	0,	0,	0),
(146,	'',	'07ac117486a82157d3c65b11c048341d',	'danabrus@hotmail.com',	1,	0,	0,	0,	0,	0),
(147,	'',	'07ac117486a82157d3c65b11c048341d',	'dany_8221@hotmail.com',	1,	0,	0,	0,	0,	0),
(148,	'',	'07ac117486a82157d3c65b11c048341d',	'elbesme_23@hotmail.com',	1,	0,	0,	0,	0,	0),
(149,	'',	'07ac117486a82157d3c65b11c048341d',	'girasolesps@gmail.com',	1,	0,	0,	0,	0,	0),
(150,	'',	'07ac117486a82157d3c65b11c048341d',	'jes.cua.06@gmail.com',	1,	0,	0,	0,	0,	0),
(151,	'',	'07ac117486a82157d3c65b11c048341d',	'juank77_01@hotmail.com',	1,	0,	0,	0,	0,	0),
(152,	'',	'07ac117486a82157d3c65b11c048341d',	'juany3286@gmail.com',	1,	0,	0,	0,	0,	0),
(153,	'',	'07ac117486a82157d3c65b11c048341d',	'julideseado@live.com.ar',	1,	0,	0,	0,	0,	0),
(154,	'',	'07ac117486a82157d3c65b11c048341d',	'karenacostapaez@gmail.com',	1,	0,	0,	0,	0,	0),
(155,	'',	'07ac117486a82157d3c65b11c048341d',	'karenrdz310@gmail.com',	1,	0,	0,	0,	0,	0),
(156,	'',	'07ac117486a82157d3c65b11c048341d',	'lau_maiorana@hotmail.com',	1,	0,	0,	0,	0,	0),
(157,	'',	'07ac117486a82157d3c65b11c048341d',	'lou_toledo@Hotmail.com.ar',	1,	0,	0,	0,	0,	0),
(158,	'',	'07ac117486a82157d3c65b11c048341d',	'louvirau@hotmail.com',	1,	0,	0,	0,	0,	0),
(159,	'',	'07ac117486a82157d3c65b11c048341d',	'magdalenavcr@hotmail.com',	1,	0,	0,	0,	0,	0),
(160,	'',	'07ac117486a82157d3c65b11c048341d',	'majo0772@gmail.com',	1,	0,	0,	0,	0,	0),
(161,	'',	'07ac117486a82157d3c65b11c048341d',	'mariajoseg077@gmail.com',	1,	0,	0,	0,	0,	0),
(162,	'',	'07ac117486a82157d3c65b11c048341d',	'melinaalfano_85@yahoo.com.ar',	1,	0,	0,	0,	0,	0),
(163,	'',	'07ac117486a82157d3c65b11c048341d',	'migliorelaura03@gmail.com',	1,	0,	0,	0,	0,	0),
(164,	'',	'07ac117486a82157d3c65b11c048341d',	'monica.rojas@osde.com.ar',	1,	0,	0,	0,	0,	0),
(165,	'',	'07ac117486a82157d3c65b11c048341d',	'morenaima22@gmail.com',	1,	0,	0,	0,	0,	0),
(166,	'',	'07ac117486a82157d3c65b11c048341d',	'pao.panima@hotmail.com',	1,	0,	0,	0,	0,	0),
(167,	'',	'07ac117486a82157d3c65b11c048341d',	'patriciavillarroel1367@gmail.com',	1,	0,	0,	0,	0,	0),
(168,	'',	'07ac117486a82157d3c65b11c048341d',	'prof.elsa78@gmail.com',	1,	0,	0,	0,	0,	0),
(169,	'',	'07ac117486a82157d3c65b11c048341d',	'ruthlopez1246@gmail.com',	1,	0,	0,	0,	0,	0),
(170,	'',	'07ac117486a82157d3c65b11c048341d',	'sonytorres67@yahoo.com.ar',	1,	0,	0,	0,	0,	0),
(171,	'',	'07ac117486a82157d3c65b11c048341d',	'valeariel45@gmail.com',	1,	0,	0,	0,	0,	0),
(172,	'',	'07ac117486a82157d3c65b11c048341d',	'viviana_lara@hotmail.com',	1,	0,	0,	0,	0,	0),
(173,	'',	'07ac117486a82157d3c65b11c048341d',	'yany.valenzuela@gmail.com',	1,	0,	0,	0,	0,	0),
(174,	'',	'07ac117486a82157d3c65b11c048341d',	'yesicamartelpsp@gmail.com',	1,	0,	0,	0,	0,	0);

DROP TABLE IF EXISTS `pow_users_cursos`;
CREATE TABLE `pow_users_cursos` (
  `userID` int(11) NOT NULL,
  `cursoID` int(11) NOT NULL,
  `estado` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pow_users_cursos` (`userID`, `cursoID`, `estado`) VALUES
(8,	1,	2),
(8,	2,	1),
(8,	3,	1),
(4,	1,	2),
(6,	2,	2),
(6,	1,	2);

DROP TABLE IF EXISTS `pow_users_docs`;
CREATE TABLE `pow_users_docs` (
  `userID` int(11) NOT NULL,
  `ddjj` int(1) NOT NULL,
  `antecedentes` int(1) NOT NULL,
  `video` int(1) NOT NULL,
  `identificacion` int(1) NOT NULL,
  `foto` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pow_users_docs` (`userID`, `ddjj`, `antecedentes`, `video`, `identificacion`, `foto`) VALUES
(3,	0,	0,	0,	0,	0),
(6,	0,	0,	0,	0,	0);

DROP TABLE IF EXISTS `pow_users_pagos`;
CREATE TABLE `pow_users_pagos` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `cursoID` int(11) NOT NULL,
  `medio` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `estado` int(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pow_users_pagos` (`Id`, `userID`, `cursoID`, `medio`, `estado`) VALUES
(8,	3,	2,	'Paypal',	2),
(9,	3,	1,	'Mercado Pago',	2);

DROP TABLE IF EXISTS `pow_users_perfil`;
CREATE TABLE `pow_users_perfil` (
  `userID` int(11) NOT NULL,
  `nombre` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `apellido` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `nacimiento` date NOT NULL,
  `dni` int(8) NOT NULL,
  `estado_civil` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `pais` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `provincia` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ciudad` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `cp` int(10) NOT NULL,
  `celular` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `fijo` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `nacionalidad` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `religion` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `proaborto` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `tratamiento` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `medicacion` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `trabajo` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `referencia1_nombre` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `referencia1_email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `referencia1_celular` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `referencia2_nombre` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `referencia2_email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `referencia2_celular` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `razones` text COLLATE utf8_unicode_ci NOT NULL,
  `concepcion` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pow_users_perfil` (`userID`, `nombre`, `apellido`, `nacimiento`, `dni`, `estado_civil`, `pais`, `provincia`, `ciudad`, `direccion`, `cp`, `celular`, `fijo`, `nacionalidad`, `religion`, `proaborto`, `tratamiento`, `medicacion`, `trabajo`, `referencia1_nombre`, `referencia1_email`, `referencia1_celular`, `referencia2_nombre`, `referencia2_email`, `referencia2_celular`, `razones`, `concepcion`) VALUES
(3,	'Franco Daniel',	'Ocaranza',	'1985-12-04',	31842369,	'Soltero/a',	'Argentina',	'Tucumán',	'Las Talitas',	'Bº SOEME M7 C27',	4101,	'+5493816307673',	'',	'Argentino',	'Cristiana Evangélica',	'En contra',	'No',	'No',	'Sí. Escuela bíblica.',	'asdasd',	'asdasd',	'asdasd',	'asdasd',	'asdasd',	'No',	'No quiero',	'Papá, mamá, hijos.'),
(6,	'Tomás Daniel',	'Ocaranza',	'2021-05-18',	54023555,	'Soltero/a',	'Argentina',	'Tucumán',	'Tafí Viejo',	'Bº Lomas de Tafí M.6 C.22 S.12',	4000,	'3815656222',	'',	'Argentino',	'Cristiana Evangélica',	'A favor',	'No',	'No',	'Sí. En casa.',	'Franco Ocaranza (Papá)',	'netfrank777@gmail.com',	'3816307673',	'Cholandia',	'chocoloco@gmail.com',	'3816523654',	'Porque quiero.',	'Padre, Madre, hijos.'),
(133,	'Alexia Janet',	'Cruz',	'1996-03-23',	39573764,	'Casado/a',	'Argentina',	'Tucumán',	'San Miguel de Tucumán',	'Cristo rey 830 manantial',	0,	'3816090652',	'',	'Argentina',	'Cristiana evangélica',	'En contra',	'',	'',	'Escuela bíblica (vision apostólica)',	'',	'',	'',	'',	'',	'',	'Actualmente estoy trabajando con niños y deseo aprender sobre indicadores del ASI',	''),
(134,	'alicia',	'roncoroni',	'1953-07-30',	10970072,	'Casado/a',	'argentina',	'santa cruz',	'puerto deseado',	'Ezequiel ramos Mejía 2138',	0,	'2974136313',	'',	'argentina',	'cristiana evangelica (pastora)',	'En contra',	'',	'',	'en la escuela bíblica',	'',	'',	'',	'',	'',	'',	'porque tristemente cada vez hay mas abusos dentro de los hogares y quiero detectarlos y denunciarlos o tratar de evitarlos seria lo mejor',	''),
(135,	'Mónica Andrea',	'Aranda',	'1978-09-27',	26861039,	'Soltero/a',	'Argentina',	'Buenos aires',	'Carmen de Patagones',	'Domingo López 521',	0,	'2,92015E+11',	'',	'Argentina',	'Cristiana evangélica',	'En contra',	'',	'',	'En la iglesia',	'',	'',	'',	'',	'',	'',	'Creo necesario ,ya que nuestra labor activa dentro de la sociedad ,y como comidas cristiana recibimos muchos casos y debemos prepararnos para aportar herramientas no solo en lo Espiritual sino que también con herramientas de personas que son entendidas en el tema como la fundación Epasi. Aprovecho para felicitarles x la gran labor que hacen y les ánimo y admiro su gran labor !!',	''),
(136,	'Viviana Mariel',	'Ayala peña',	'1989-02-08',	34333102,	'Casado/a',	'Argentina',	'Buenos Aires',	'Bahia Blanca',	'chacabuco 3241',	0,	'2914407364',	'',	'Argentina',	'Cristiana Evangélica',	'En contra',	'',	'',	'Como maestra de escuela biblica',	'',	'',	'',	'',	'',	'',	'Soy estudiante avanzada de la carrera de Abogacia en la U.N.S de bahia Blanca y quisiera enfocar mi carrera en la Defensoría de los menores.',	''),
(137,	'Daiana Belen',	'Ramos',	'1992-04-11',	36302760,	'Casado/a',	'Argentina',	'Buenos aires',	'Carmen de patagones',	'Julia Dufour 631',	0,	'2920263179',	'',	'Argentina',	'Cristiana',	'En contra',	'Ninguno',	'',	'Iglesia de niños',	'',	'',	'',	'',	'',	'',	'Para ayudar a los niños y también a su padres, para prevenir cualquier abuso que esten pasando',	''),
(138,	'Betiana',	'Salvo',	'2019-09-11',	28400072,	'Casado/a',	'Argentins',	'Neuquen',	'Neuquen',	'San Antonio 1040',	0,	'2994599565',	'',	'Argentina',	'Evangelica',	'En contra',	'',	'',	'Jardin Maternl Municipal y en casa kids d Casa de las Naciones',	'',	'',	'',	'',	'',	'',	'Debido a una experiencia familiar y no supe como ayudar y otra porq trabajo con niños y deseo poder enseñar estas herramientas para prevenir los abusos sexuales.',	''),
(139,	'Carla',	'Taboada de Perello',	'1974-03-11',	1453936,	'Casado/a',	'Paraguay',	'Asuncion',	'Asuncion',	'Ygatimi Casi Colon',	0,	'981831183',	'',	'paraguaya',	'cristiana evangelica',	'En contra',	'Ninguno',	'',	'En la iglesia',	'',	'',	'',	'',	'',	'',	'Me interesa el curso porque estoy coordinando un proyecto de la Fundación Huellas de Amor de la Iglesia Mas que Vencedores, donde trabajamos en la prevención de abuso sexual infantil por medio de charlas, talleres, campañas, grupos de apoyo a personas que han pasado por abuso, y otras actividades, y considero muy importante seguir capacitandome en el tema.',	''),
(140,	'Carlos Alejandro',	'Muñoz Romero',	'1962-12-10',	78116803,	'Casado/a',	'Chile',	'Valdivia',	'Valdivia',	'Romero Arturo Prat 507 depto. ',	0,	'983612605',	'',	'Chilena',	'No aplica',	'En contra',	'Ninguno',	'',	'indirectamente, atendido la función como Administrador del Tribunal Oral en lo Penal de Valdivia',	'',	'',	'',	'',	'',	'',	'Como miembro del Poder Judicial estoy en un proyecto de investigación de la materia, básicamente por la carencia de políticas públicas en la prevención, área que se pretende hacer un aporte al menos regional (región de los Ríos - Chile)',	''),
(141,	'Maria Ana Catalina',	'Razo Murillo',	'1993-11-15',	0,	'Soltero/a',	'México',	'Nuevo León',	'Monterrey',	'Nayarit 2211',	0,	'8110094177',	'',	'Mexicana',	'Católica',	'En contra',	'',	'',	'Como voluntaria en Educación y Formación Ohana, A.C. / prestadora de servicio social en Amig@ UANL / docente a nivel primaria, secundaria y preparator',	'',	'',	'',	'',	'',	'',	'He trabajado con niños en situación de vulnerabilidad desde los 17 años. México es un país en el que abunda la violencia hacia nuestros niños, niñas y adolescentes, especialmente la de índole sexual, registrándose más de 6,000 casos de abuso denunciados al año, considerando que muchos de ellos no llegan a denuncia (se estima que solamente 20% llegan ante la Ley). En enero de 2019 fundé una ONG llamada PIA - Protección a la Infancia y la Adolescencia, que tiene como objetivo prevenir el abuso sexual infantil en el norte del país, pues contamos con pocas ciudades que hacen esto (la mayoría solamente tiene protocolos de acción cuando el abuso ya ocurrió). Realizamos talleres para niños, niñas y adolescentes, además de talleres para padres de familia, maestros y sociedad con un objetivo: blindar a nuestros pequeños para prevenir el abuso sexual infantil.',	''),
(142,	'Claudio',	'Caprarulo',	'1980-05-27',	28109690,	'Divorciado',	'Argentina',	'Buenos Aires',	'Moreno',	'Avenida Saavedra Lamas 7124',	0,	'5,49112E+12',	'',	'Argentino',	'Evangélico',	'En contra',	'Ninguno',	'',	'Ninguno',	'',	'',	'',	'',	'',	'',	'Para aprender a detectar casos de abusos y ayudar a las víctimas.',	''),
(143,	'María Celeste',	'Rodríguez Invernizzi',	'1989-10-16',	3438042,	'Casado/a',	'Paraguay',	'Central',	'Asunción',	'Pitiantuta casi concordia 1131',	0,	'982777714',	'',	'Paraguaya',	'Cristiana',	'En contra',	'Ninguno',	'',	'Maestra de niños',	'',	'',	'',	'',	'',	'',	'Soy trabajadora social y debo estar capacitada para abordar un tema tan importante',	''),
(144,	'Claudia Noemí',	'García',	'1966-07-14',	17506995,	'Casado/a',	'Argentina',	'Buenos Aires',	'San Bernardo',	'Garay 204',	0,	'2257611928',	'',	'Argentina',	'cristiana evangelica',	'En contra',	'Ninguno',	'',	'no',	'',	'',	'',	'',	'',	'',	'Me interesa capacitarme para poder servir a la comunidad con la prevención de un tema tan importante como lo es el abuso sexual infantil. Como capellán cristiano debo formarme en algunas áreas y el Señor a puesto en mi corazón está problematica tan dolorosa como lo es el abuso. Trabajar en la prevención, en diferentes ámbitos como en escuelas, centros comunitarios, medios de comunicación. etc',	''),
(145,	'Sanchez Bulacio',	'Carla Pamela',	'1986-08-17',	32349273,	'Casado/a',	'Argentina',	'La Rioja',	'La Rioja',	'Calle República Argentina S/N ',	0,	'3804951593',	'',	'Argentina',	'Católico',	'En contra',	'',	'',	'Catequesis',	'',	'',	'',	'',	'',	'',	'Para poder ayudar en donde se requiera y evitar que se siga dando este flagelo en la familias',	''),
(146,	'Daniela',	'Brusain',	'1985-03-03',	31528356,	'Casado/a',	'Argentina',	'Río Negro',	'Villa Regina',	'Liniers 583',	0,	'2,99154E+11',	'',	'Argentina',	'Evangelica',	'En contra',	'',	'',	'Escuela bíblica en iglesia y dónde trabajo defensoría de menores',	'',	'',	'',	'',	'',	'',	'Me interesa la tematica por el lugar donde trabajo, defensoría de menores, y porque en la iglesia donde me congregó trabajo con niños.',	''),
(147,	'Ruth Daniela',	'Aguero',	'1986-10-04',	32568693,	'Casado/a',	'Argentina',	'Chubut',	'Rawson',	'Caridad Allier 170, Área 12',	0,	'2804340481',	'',	'Argentina',	'Evangelio',	'En contra',	'Ninguno',	'',	'Escuela 170 e iglesia local',	'',	'',	'',	'',	'',	'',	'Soy profesora de educación primaria y trabajo en el ministerio de misioneritas de mi iglesia,debido a ello interactivo continuamente con niños y niñas. Quisiera estar preparada para detectar abusos y contar con las herramientas necesarias para brindar ayuda.',	''),
(148,	'Elba Esmeralda',	'Lechare',	'1951-01-23',	6540606,	'Casado/a',	'Argentina',	'Santa fe',	'Recreo',	'Martin de Guemes 608',	0,	'3425522723',	'',	'Argentina',	'evangelico pentecostal',	'En contra',	'',	'',	'en la escuela',	'',	'',	'',	'',	'',	'',	'DIOS ME DIO MUCHO AMOR POR LOS NIÑOS Y ADOLESCENTES Y ME GUSTA ESCUCHARLOS Y AYUDARLOS PARA PREVENIRLOS ANTE SITUACIONES DE RIESGOS CUANDO HAY SITUACIONES DE ESTE TIPO, SE NECESITA MAS CONOCIMIENTO Y SABIDURIA EN ESTOS TIEMPOS DIFICILES.GRACIAS POR BRINDAR ESTOS RECURSOS.. MUCHAS BENDICIONES!',	''),
(149,	'PAOLA',	'DELGADO',	'1976-09-29',	1308854114,	'Soltero/a',	'ECUADOR',	'MANABI',	'MONTECRISTI',	'CALLE 10 DE AGOSTO Y ROCAFUERT',	0,	'994890930',	'',	'ECUATORIANA',	'EVANGELICA',	'En contra',	'',	'',	'FUNDACIONES E INSTITUCIONES EDUCATIVAS',	'',	'',	'',	'',	'',	'',	'Trabajo en esta área de prevención de abuso y violencia desde hace 10 años en fundaciones e instituciones educativas. Y dentro de unas semanas estaré coordinando un centro de Prevención, Intervención y Empoderamiento en esta problemática social.',	''),
(150,	'jesica daiana',	'cuadrado',	'1989-07-17',	35020658,	'Casado/a',	'argentina',	'buenos aires',	'carmen de patagones',	'Joaquin maza 666',	0,	'2920288652',	'',	'argentina',	'cristiana evangelica',	'En contra',	'',	'',	'Animacion de fiestas infantiles',	'',	'',	'',	'',	'',	'',	'Por que creo que es necesario en estos tiempos prepararnos y tener los conocimientos necesarios para trabajar con los niños, la infancia es una etapa muy bulnerable y es la mas corrompida. A su vez capacitarme aun mas en el area donde sirvo.',	''),
(151,	'juan Carlos',	'ayelef',	'2019-12-31',	34668019,	'Casado/a',	'Argentina',	'rio negro',	'viedma',	'french 216',	0,	'2920527729',	'',	'Argentina',	'ecangelio',	'En contra',	'',	'',	'iglesia',	'',	'',	'',	'',	'',	'',	'Hola mi interés es formarme, y capacitarme para poder contrarrestar todas estas leyes y grupos que se quieren levantar encontra de nuestros principios,',	''),
(152,	'Juana',	'Marin',	'2019-07-25',	32390291,	'Casado/a',	'Argentina',	'Viedma',	'Viedma',	'Rio Negro 8500 Viedma Argentin',	0,	'15361286',	'',	'Argentina',	'Cristiana',	'En contra',	'',	'',	'Como auxiliar estado y dentro de escuelita de niño iglesia',	'',	'',	'',	'',	'',	'',	'Para poder inplimentarlo en el sector de iglesia donde pertenezco centro cristiano restaurador',	''),
(153,	'Julieta Beatriz',	'Zabala',	'1974-09-21',	24028856,	'Casado/a',	'Argentina',	'Santa Cruz',	'Puerto Deseado',	'Crucero Gral Belgrano 2020',	0,	'2975382721',	'',	'Argentina',	'Cristiana Evangelica',	'En contra',	'',	'',	'Escuela Bíblica infantil',	'',	'',	'',	'',	'',	'',	'Porque como en toda ciudad el abuso es algo muy frecuente, y necesitamos herramientas para incertarnos y como iglesia involucranos en la sociedad estando capacitados para hacerlo no solamente en el área espiritual como hasta ahora nos ha tocado . Creo que la capacitación es fundamental para poder hacer bien esta tarea .',	''),
(154,	'Karen',	'Paez',	'1974-02-14',	23639398,	'Casado/a',	'Argentina',	'Córdoba',	'Juarez Celman',	'El ombu 129',	0,	'3518002342',	'',	'Argentina',	'Evangelica',	'En contra',	'',	'',	'En la iglesia',	'',	'',	'',	'',	'',	'',	'Para poder ayudar a padres a prevenir el abuso de sus niños darles herramientas de como enseñar a sus hijos a pedir ayuda ante alguna situación de abuso. Yo fui abusada mis padres nunca se dieron cuenta y yo tenía miedo de decirles por eso me parece muy importante formarme como preventora para ser de ayuda a la comunidad',	''),
(155,	'Karen Alicia',	'Rodrìguez Guzmàn',	'1995-10-03',	0,	'Soltero/a',	'Mexico',	'Nuevo Leòn',	'Monterrey',	'Jesus Gonzàlez Ortega',	0,	'8119146632',	'',	'Mexicana',	'No',	'En contra',	'',	'',	'Psicologa escolar, talleres de prevenciòn del abuso sexual',	'',	'',	'',	'',	'',	'',	'Siendo parte de una asociación dedicada a la prevención del abuso sexual infantil me siento con la responsabilidad de estar preparada teórica y prácticamente para el proceso, asimismo, dar información actualizada y verídica.',	''),
(156,	'Laura',	'Maiorana',	'1986-03-19',	32358262,	'Soltero/a',	'Argentina',	'Buenos aires',	'Buenos aires',	'Montgolfiel 4844 grio de lafer',	0,	'1561816218',	'',	'Argentina',	'Cristiana evangelica',	'En contra',	'',	'',	'Como psicologa y en mi congregacion (centro familiar cristiano)',	'',	'',	'',	'',	'',	'',	'Creo que es muy importante capacitarse en un tema tan delicado. Como psicologa es necesario',	''),
(157,	'Lourdes Rosalía',	'Toledo',	'1991-05-05',	35922056,	'Divorciado',	'Argentina',	'Tucumán',	'Yerba Buena',	'Belisario Roldán 748 y pje Ig.',	0,	'153035470',	'',	'Argentina',	'Cristiana',	'En contra',	'Psicológico',	'',	'Año completo en prácticas profecionalizantes de carrera T. Fonoaudiologo en la Escuela Luis Braile. Y un año de maestra de escuela bíblica.',	'',	'',	'',	'',	'',	'',	'Primero soy madre y siento que necesito herramientas útiles para detectar y trabajar con mis hijos. Y segundo para ampliar información y el trabajo en los chicos de la Iglesia dónde me congrego. Es importante la prevención y detección.',	''),
(158,	'Lourdes',	'Oviedo',	'1963-08-22',	93286572,	'Casado/a',	'Argentina',	'Bueno Aires',	'San Martin',	'Antartida Argentina',	0,	'1551080317',	'',	'Brasileiro',	'Evangélica pentecostal',	'En contra',	'Ninguno',	'',	'Brasil ED',	'',	'',	'',	'',	'',	'',	'Carga por Llos niños violados, ya que una de mis hijas fue violada.',	''),
(159,	'Magdalena del valle',	'Cabrera',	'1976-08-29',	25320761,	'Casado/a',	'Argentina',	'Tucuman',	'Concepcion',	'Rivadavia453',	0,	'3865678014',	'',	'Argentina',	'Evangelica',	'En contra',	'',	'',	'En la iglesia donde pertenezco',	'',	'',	'',	'',	'',	'',	'La razon es por la necesidad que hay de ayudar y poder proveer algun tipo de soluciones estamos rodeados de niños y adolecente,con problemas de este tipo es importante tener herramienta y formacipn para poder ayudarlos',	''),
(160,	'María José',	'Hermosilla',	'1990-07-14',	35310222,	'Casado/a',	'Argentina',	'Neuquén',	'Neuquén',	'Gobernador Quarta 1474',	0,	'2995773385',	'',	'Argentina',	'Evangélica',	'En contra',	'',	'',	'Escuela bíblica y auxiliar de servicio en escuela pública',	'',	'',	'',	'',	'',	'',	'Para ser de ayudar con el grupo que está trabajando en Neuquén y para poder ser útil en las necesitades que se presentan en los grupos de niños donde trabajo.',	''),
(161,	'María José',	'González',	'1977-07-08',	25818339,	'Soltero/a',	'Argentina',	'Tucumán',	'Juan Bautista Alberdi',	'Pje Paz y Paraná Mza A casa 6 ',	0,	'5,43866E+11',	'',	'Argentina',	'Católica apostólica romana',	'En contra',	'',	'',	'En el Hogar de Niñas San José de las Hermanas Esclavas y en Acción Católica en el Área Aspirantes, Caritas Arquidiocesana ,soy Catequesista',	'',	'',	'',	'',	'',	'',	'Creo que el abuso infantil es el más aberrante de los crímenes , y no basta con pedir justicia luego de que estos hechos suceden. Es necesaria la Prevención y cuidar que nuestros niños no deban pasar por una situación así',	''),
(162,	'Melina Vanesa',	'Alfano',	'1985-03-11',	31429556,	'Casado/a',	'Argentina',	'Mendoza',	'Junin',	'2 barrio Jardín Ferroviario Mn',	0,	'2634658199',	'',	'Argentina',	'Cristiana evangelica',	'En contra',	'Ninguno',	'',	'Con adolescentes en una escuela secuandaria',	'',	'',	'',	'',	'',	'',	'Quiero poder ayudar a los niños que pasaron por un abuso y también ayudar a los que no a prevenir esa situación. Sé que con esta herramienta y con ayuda de Dios los niños podrán ser restaurados.',	''),
(163,	'Laura Edith',	'Migliore',	'1978-05-06',	26541170,	'Casado/a',	'Argentina',	'Neuquén',	'Plottier',	'Percy Clark 1180.',	0,	'2,99155E+11',	'',	'Argentina',	'Cristiana - Evangelica',	'En contra',	'Ninguno',	'',	'Actualmente escuela primaria, anteriormente ministerio de la iglesia',	'',	'',	'',	'',	'',	'',	'En mi trabajo (soy docente) he presenciado, y he sido obligada a pasar por alto, distintas situaciones, respecto a la integridad física y psíquica de alguno de mis alumnos, y no he actuado de la manera adecuada por no tener las herramientas y el conocimiento necesario al respecto. Actualmente estoy estudiando tecnicatura en niñez, adolescencia y familia, pero si bien me da cierta orientación y me brinda herramientas, no es una formación en valores, ni esta basada en principios éticos del cristianismo.',	''),
(164,	'Mónica',	'Rojas',	'1971-06-05',	18773246,	'Casado/a',	'Argentina',	'Neuquen',	'Neuquen',	'Veron 1570',	0,	'2994060790',	'',	'Argentina',	'Cristiana',	'En contra',	'',	'',	'No',	'',	'',	'',	'',	'',	'',	'Quiero tener herramientas para trabajar con niños en mi iglesia ( Iglesia El Camino, de Neuquén)',	''),
(165,	'Rebeca Beatriz',	'Pardo',	'1992-01-30',	36664473,	'Casado/a',	'Argentina',	'Salta',	'Capital',	'Barrio Parque la Vega B 40 dpt',	0,	'3876315340',	'',	'Argentina',	'Cristiana',	'En contra',	'Ninguno',	'',	'Si y adolescentes en la Escuela 4042 (mantenimiento) y en mis prácticas pre profesionales a fines a mi carrera y soy madre de dos niñas.',	'',	'',	'',	'',	'',	'',	'Soy estudiante de la carrera Técnico Superior en Familia y Niñez y el curso me será de gran ayuda para futuras intervenciones en comunidad. Así como mencione anteriormente también soy madre de dos niñas y me será de gran utilidad para seguir enseñándoles cómo proteger su cuerpo.',	''),
(166,	'Paola',	'Rodríguez',	'1984-11-30',	31138398,	'Soltero/a',	'Argentina',	'Buenos Aires',	'General Rodríguez',	'La Rioja 410',	0,	'1168401134',	'',	'Argentina',	'No',	'En contra',	'',	'',	'Escuelas',	'',	'',	'',	'',	'',	'',	'Para poder Ayudara prevenir y ayudar a superar traumas',	''),
(167,	'Patricia Andrea',	'Villarroel',	'1975-11-22',	24648770,	'Casado/a',	'Argentina',	'Río Negro',	'Villa Regina',	'23 de septiembre',	0,	'2984887412',	'',	'Argentina',	'Evangelica',	'En contra',	'',	'',	'Escuelas',	'',	'',	'',	'',	'',	'',	'Soy docente y trabajo con niños de escuela primaria y a la vez en el ministerio infantil de la congregación a la que pertenezco, quiero capacitarme en esta temática ya que considero que aportara herramientas que me permitirá ayudar a los niños y adolescentes que me rodean',	''),
(168,	'Elsa Beatriz',	'Pereyra',	'1978-03-22',	26490284,	'Soltero/a',	'Argentina',	'Cordoba',	'Cordoba',	'Chavisacate 1647 Barrio Leandr',	0,	'3518043495',	'',	'Argentina',	'Catolicismo',	'En contra',	'Ninguno',	'',	'Escuelas',	'',	'',	'',	'',	'',	'',	'Me preocupa la ESI implementada por el gobierno, y deseo colaborar como preventora por las infancias.',	''),
(169,	'Ruth Elizabeth',	'Lopez',	'1972-02-05',	21947879,	'Casado/a',	'Argentina',	'Mendoza',	'San Martín',	'Gran Líbano 355',	0,	'2634562785',	'',	'Argentina',	'Evangelica',	'En contra',	'Ninguno',	'',	'Escuelas',	'',	'',	'',	'',	'',	'',	'Para tener herramienta y poder usarlas en las escuelas donde trabajo',	''),
(170,	'Sylvia Sonia',	'Torres',	'1967-04-09',	18398438,	'Casado/a',	'Argentina',	'La Rioja',	'La Rioja capital',	'La Paz 275.Barrio Los Cerros',	0,	'3804373193',	'',	'Argentina',	'Católica Apostólica Romana',	'En contra',	'',	'',	'Si como Asesora Pedagógica Colegios Privados Religiosos',	'',	'',	'',	'',	'',	'',	'Considero que es una problemática que en mi caso hoy como legisladora puedo aportar muchísimo y segundo como. ASESORA PEDAGÓGICA',	''),
(171,	'Mirna Valeria',	'Castillo',	'1980-08-27',	28021530,	'Casado/a',	'Argentina',	'Santa Cruz',	'Caleta Olivia',	'Los Andes 1404',	0,	'2973700784',	'',	'Argentina',	'Cristiana Evangélica',	'En contra',	'',	'',	'En la iglesia a la que asisto',	'',	'',	'',	'',	'',	'',	'Quisiera realizar el curso de prevención de abuso porque trabajo con niños en la institución esclesiastica a la que pertenezco ,y en este último tiempo he tenido varios alumnos que han sufrido abuso sexual y en muchos de estos casos he sentido que no tenía las herramientas para ayudarles por lo cual es un desafío para mí el capacitarme en esta área',	''),
(172,	'viviana',	'lara',	'1977-03-12',	25862228,	'Otra',	'Argentina',	'Neuquen',	'ZAPALA',	'barrio 582 viv. acceso L 2 Pla',	0,	'2,94215E+11',	'',	'Argentina',	'ninguna',	'En contra',	'Ninguno',	'',	'Con niños y adolescentes victimas de abusos de diferente tipo de delitos. Centro de asistencia a la victima - Eaopie (Equipo de apoyo a las institucio',	'',	'',	'',	'',	'',	'',	'porque me gustaría convertirme en formadora de la temática, a diario me toca intervenir en el tema.',	''),
(173,	'Alessandra Yanina',	'Valenzuela',	'1991-09-04',	36372018,	'Casado/a',	'argentina',	'neuquen',	'neuquen',	'lainez 1050',	0,	'2994654299',	'',	'argentina',	'Iglesia Bautista',	'En contra',	'',	'',	'no',	'',	'',	'',	'',	'',	'',	'Quisiera formarme como preventora para trabajar a futuro con niños en situacion de abuso, estudio actualmente una tecnicatura universitaria en acompañante terapeutico.',	''),
(174,	'Natalia',	'Martel',	'1984-06-05',	31067860,	'Casado/a',	'Argentina',	'GREGORIO DE LAFERRERE',	'Buenos Aires',	'Carlos Casares 5384 PB Dto 3',	0,	'1133725176',	'',	'Argentina',	'Cristiana evangélica',	'En contra',	'Ninguno',	'',	'Consultorio y escuela',	'',	'',	'',	'',	'',	'',	'Prepararme para entrar en barrios, plazas, comedores comunitarios, etc.y dar a conocer e identificar cuando está en peligro. Desde la prevención y la intervención.',	'');

DROP TABLE IF EXISTS `pow_users_preventores`;
CREATE TABLE `pow_users_preventores` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `lugar` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `certificado` text COLLATE utf8_unicode_ci NOT NULL,
  `lugar_aplicacion` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `edad_nivel` text COLLATE utf8_unicode_ci NOT NULL,
  `reporte` text COLLATE utf8_unicode_ci NOT NULL,
  `revelacion` text COLLATE utf8_unicode_ci NOT NULL,
  `explicacion` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pow_users_preventores` (`Id`, `userID`, `lugar`, `fecha`, `certificado`, `lugar_aplicacion`, `edad_nivel`, `reporte`, `revelacion`, `explicacion`) VALUES
(1,	7,	'',	'0000-00-00',	'',	'',	'',	'',	'',	''),
(2,	6,	'Mi casa',	'2020-01-01',	'SI',	'Donde sea',	'20',	'No',	'No',	'No intervine'),
(3,	4,	'Mi casa.',	'2020-01-01',	'No. No quiero.',	'En mi casa. Este año.',	'3 a 12 años',	'No. No quiero.',	'No ',	'Nada'),
(4,	3,	'',	'0000-00-00',	'',	'',	'',	'',	'',	''),
(5,	175,	'',	'0000-00-00',	'',	'',	'',	'',	'',	'');

DROP TABLE IF EXISTS `pow_users_respuestas`;
CREATE TABLE `pow_users_respuestas` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `claseID` int(11) NOT NULL,
  `preguntaID` int(11) NOT NULL,
  `respuesta` text COLLATE utf8_unicode_ci NOT NULL,
  `feedback` text COLLATE utf8_unicode_ci NOT NULL,
  `estado` int(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pow_users_respuestas` (`Id`, `userID`, `claseID`, `preguntaID`, `respuesta`, `feedback`, `estado`) VALUES
(4,	4,	8,	7,	'Esta es la respuesta más larga del usuario. No vamos a entrar en detalles, porque sería muy molesto, pero bueh; la idea es que es una respuesta larga que debería llegar a ocupar al menos cuatro líneas.',	'Está perfecto! Entendiste muy bien este tema!',	2),
(5,	4,	8,	8,	'Esta es la respuesta más larga del usuario. No vamos a entrar en detalles, porque sería muy molesto, pero bueh; la idea es que es una respuesta larga que debería llegar a ocupar al menos cuatro líneas (aquí agrego algo más, y un poquito más).',	'Deberías revisar la forma en que te expresas.',	2),
(6,	4,	8,	9,	'Por favor desarrolle las consignas y haga click en el botón. Esta es la respuesta más larga del usuario. No vamos a entrar en detalles, porque sería muy molesto, pero bueh; la idea es que es una respuesta larga que debería llegar a ocupar al menos cuatro líneas.',	'',	2),
(11,	4,	9,	10,	'Esta es una de las respuestas. Está redactada para que quede lindo.',	'',	0),
(12,	4,	9,	11,	'A continuación le realizamos una serie de preguntas que servirán para evaluar la asimilación de los conceptos expuestos en la presente clase.',	'',	0),
(13,	4,	9,	12,	'Vídeo clip que forma parte de «Cristo es todo» nuestro nuevo disco de la Academia de Adoracion para niños, ADAN. Y ahora sí estaría correcta.',	'',	0),
(14,	4,	9,	13,	'Provide contextual feedback messages for typical user actions with the handful of available and flexible alert messages. Y esta también.',	'',	0),
(15,	6,	1,	14,	'Es lo mejor que vi en mi vida.',	'Fijate cómo hacés la tarea.',	2);

DROP TABLE IF EXISTS `pow_users_tareas`;
CREATE TABLE `pow_users_tareas` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `claseID` int(11) NOT NULL,
  `estado` int(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pow_users_tareas` (`Id`, `userID`, `claseID`, `estado`) VALUES
(1,	4,	8,	2),
(3,	4,	9,	0),
(4,	6,	1,	2);

-- 2020-05-03 14:17:19
